package com.fcc;

import java.util.*;
import java.util.stream.Collectors;

/**
 * This class represents the logic related to dice roll.
 * Based on the user input.
 */

public class DiceAssignment {

    public static void main(String[] args) {

        // first get user input for number of dice and number of iterations.
        System.out.println("Please enter Number Of Dices::");
        Scanner firstUserInput = new Scanner(System.in);
        System.out.println("Please enter Number Of Simulations::");
        Scanner secondUserInput = new Scanner(System.in);

        //this is to track execution time
        double executionStartTime = System.currentTimeMillis();
        long numberOfDices = firstUserInput.nextLong();
        long numberOfSimulations = secondUserInput.nextLong();

        System.out.println("Number Of Dices::"+numberOfDices);
        System.out.println("Number Of Simulations::"+numberOfSimulations);

        int rollingNumber = 0;

        //to generate a random number
        Random randomGeneratedNumber = new Random();

        // to store key value pair of sum and number of occurrences for all simulations
        Map<Double, Double> sumOfOccurrences = new HashMap<>();

        // to store sum of each game of dice rolls
        List<Integer> rollingNumberList = null;

        // iterate for each simulation
        for(int iteration = 0; iteration < numberOfSimulations; iteration++) {

            double sumOfRolls = 0.0;
            double sumOfIteration = 0;
            long diceCount = numberOfDices;

            // while loop for each game
            while(diceCount > 0) {
                rollingNumberList = new ArrayList<>();

                // generate random number for each dice and store it in list
                for(int c = 0; c < diceCount; c++){
                    // generate a number between 1 to 6
                    rollingNumber = randomGeneratedNumber.nextInt(6) +1;
                    rollingNumberList.add(rollingNumber);
                }
                // if any occurrence of 3 then sum is 0 and remove that from the list
                if(rollingNumberList.contains(3)){
                    sumOfRolls = 0.0;
                    rollingNumberList = rollingNumberList.stream().filter(d -> !d.equals(3)).collect(Collectors.toList());
                    diceCount = rollingNumberList.size();
                } else {
                    // else sum is the lowest number and remove that dice for next throw
                    sumOfRolls = rollingNumberList.stream().min(Integer :: compareTo).orElse(null);
                    diceCount--;
                }
                //total sum of each game
                sumOfIteration = sumOfIteration +sumOfRolls;
            }
            //check if key(total sum) exists in map then increment the occurrence else add that to map
            if(sumOfOccurrences.containsKey(sumOfIteration)){
                sumOfOccurrences.put(sumOfIteration, sumOfOccurrences.get(sumOfIteration) +1);
            } else {
                sumOfOccurrences.put(sumOfIteration, 1.0);
            }
        }
        // sort the key set of map in ascending order and print
        sumOfOccurrences.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(s -> System.out.println("Total "+s.getKey().intValue()+" occurs "+(s.getValue()/numberOfSimulations) +" occurred "+s.getValue()+" times."));
        double executionEndTime = System.currentTimeMillis();
        System.out.println("Total simulation took "+(executionEndTime - executionStartTime)/1000+" seconds.");
    }
}
